import io
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import app as application


@pytest.fixture
def client(tmp_path, monkeypatch):
    """Create a test client with a temp data directory."""
    monkeypatch.setattr(application, "DATA_DIR", str(tmp_path))
    monkeypatch.setattr(application, "VIDEOS_DIR", str(tmp_path / "videos"))
    monkeypatch.setattr(application, "RECORDINGS_DIR", str(tmp_path / "recordings"))
    monkeypatch.setattr(application, "PROJECTS_FILE", str(tmp_path / "projects.json"))
    os.makedirs(tmp_path / "videos", exist_ok=True)
    os.makedirs(tmp_path / "recordings", exist_ok=True)
    application.app.config["TESTING"] = True
    with application.app.test_client() as c:
        yield c


def _post(client, pid, raw):
    return client.post(
        f"/api/projects/{pid}/clips/import_preview",
        data={"file": (io.BytesIO(raw), "clips.csv")},
        content_type="multipart/form-data",
    )


def test_import_preview_mixed_csv_and_unchanged_store(client, tmp_path):
    pid = client.post("/api/projects", json={"name": "P"}).get_json()["id"]
    before = (tmp_path / "projects.json").read_bytes()
    raw = b"\xef\xbb\xbfTag Type,Start (s),End (s),Label,Notes\r\nPass,1.5,4.0,x,\r\n\r\nPass,5.0,3.0,bad,\r\n"
    rv = _post(client, pid, raw)
    assert rv.status_code == 200
    body = rv.get_json()
    assert body["preview_only"] is True
    assert body["summary"] == {"total": 2, "valid": 1, "malformed": 1, "duplicate": 0}
    assert body["rows"][0] == {"line": 2, "status": "valid", "reasons": [],
                               "clip": {"tag_type": "Pass", "start": 1.5, "end": 4.0,
                                        "label": "x", "notes": "", "players": []}}
    assert body["rows"][1] == {"line": 4, "status": "malformed",
                               "reasons": ["end must be greater than start"], "clip": None}
    assert (tmp_path / "projects.json").read_bytes() == before


def test_import_preview_bad_request_and_404(client):
    pid = client.post("/api/projects", json={"name": "P"}).get_json()["id"]
    url = f"/api/projects/{pid}/clips/import_preview"
    rv = client.post(url, data={}, content_type="multipart/form-data")
    assert rv.status_code == 400 and rv.get_json()["code"] == "bad_request"
    rv = _post(client, pid, b"\xff\xfe")
    assert rv.status_code == 400 and rv.get_json()["code"] == "bad_request"
    rv = _post(client, pid, b"Tag Type,End (s)\nPass,4.0\n")
    assert rv.status_code == 400 and rv.get_json()["code"] == "bad_request"
    rv = _post(client, "missing", b"Tag Type,Start (s),End (s)\nPass,1,2\n")
    assert rv.status_code == 404 and rv.get_json() == {"error": "Project not found"}

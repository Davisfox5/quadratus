"""Parser and validator checks for clip-manifest CSV. No external access."""

import copy
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from clip_manifest import parse_clip_csv, preview_clip_csv, validate_clip_row


def test_normalized_required_headers_keep_unknown_columns():
    data = b"  Tag Type  ,START (S), end (s) ,Duration (s),Extra\nPass,1.5,4.0,2.5,  keep me  "
    headers, records = parse_clip_csv(data)
    assert headers == ["tag type", "start (s)", "end (s)", "duration (s)", "extra"]
    assert records == [(2, ["Pass", "1.5", "4.0", "2.5", "  keep me  "])]


def test_bom_and_crlf():
    data = "\ufeffTag Type,Start (s),End (s)\r\nPass,0,1.25\r\n".encode()
    headers, records = parse_clip_csv(data)
    assert headers == ["tag type", "start (s)", "end (s)"]
    assert records == [(2, ["Pass", "0", "1.25"])]


def test_quoted_commas_and_multiline_cells():
    data = (
        'Tag Type,Start (s),End (s),Label,Notes\r\n'
        '"Pass, deep",1,2,"say ""hi""","line1\r\nline2"\r\n'
        "Shot,3,4,plain,ok\r\n"
    ).encode()
    _, records = parse_clip_csv(data)
    assert records[0] == (2, ["Pass, deep", "1", "2", 'say "hi"', "line1\r\nline2"])
    assert records[1] == (4, ["Shot", "3", "4", "plain", "ok"])


def test_blank_records_skipped_and_lines_stay_physical():
    data = b"Tag Type,Start (s),End (s),Label\n\n,,,\n ,,,\nPass,1,2,x\n"
    _, records = parse_clip_csv(data)
    assert records == [(4, [" ", "", "", ""]), (5, ["Pass", "1", "2", "x"])]


def test_wrong_width_records_retained():
    data = b"Tag Type,Start (s),End (s),Label\nonly-two,1\nPass,1,2,lab,extra\n"
    _, records = parse_clip_csv(data)
    assert records == [(2, ["only-two", "1"]), (3, ["Pass", "1", "2", "lab", "extra"])]


def test_invalid_encoding():
    with pytest.raises(ValueError, match="UTF-8"):
        parse_clip_csv(b"Tag Type,Start (s),End (s)\n\xff\n")


def test_missing_required_headers():
    with pytest.raises(ValueError, match="missing required header: tag type"):
        parse_clip_csv(b"Start (s),End (s)\n0,1\n")
    with pytest.raises(ValueError, match=r"end \(s\)"):
        parse_clip_csv(b"Tag Type,Start (s),Label\nPass,1,x\n")
    with pytest.raises(ValueError, match="missing required header"):
        parse_clip_csv(b"")


def test_row_limit_boundary():
    header = "Tag Type,Start (s),End (s)\n"
    ok = (header + "\n" + "".join(f"T,{i},{i + 1}\n" for i in range(5000))).encode()
    _, records = parse_clip_csv(ok)
    assert (len(records), records[0], records[-1][0]) == (5000, (3, ["T", "0", "1"]), 5002)
    over = (header + "".join(f"T,{i},{i + 1}\n" for i in range(5001))).encode()
    with pytest.raises(ValueError, match="^too_many_rows$"):
        parse_clip_csv(over)


PROJECT = {
    "tag_types": [{"name": "Pass"}, {"name": "Shot"}],
    "players": [
        {"id": "p1", "name": "Alex", "number": "7"},
        {"id": "p2", "name": "Blair", "number": "10"},
    ],
}
HEADERS = ["tag type", "start (s)", "end (s)", "label", "notes", "players"]


def test_validate_normalizes_and_preserves_optional_text():
    fields = [" Pass ", " 1.5 ", "4", "  label  ", "notes\nkept", " Alex ; #10 "]
    fields_before, project_before = copy.deepcopy(fields), copy.deepcopy(PROJECT)
    clip, reasons = validate_clip_row(HEADERS, fields, PROJECT)
    assert reasons == []
    assert clip == {"tag_type": "Pass", "start": 1.5, "end": 4.0,
                    "label": "  label  ", "notes": "notes\nkept", "players": ["p1", "p2"]}
    assert fields == fields_before and PROJECT == project_before


def test_validate_optional_defaults_and_ignored_columns():
    clip, reasons = validate_clip_row(
        ["tag type", "start (s)", "end (s)", "duration (s)", "extra"],
        ["Shot", "0", "2", "999", "ignored"], PROJECT)
    assert reasons == []
    assert clip == {"tag_type": "Shot", "start": 0.0, "end": 2.0,
                    "label": "", "notes": "", "players": []}


@pytest.mark.parametrize("players", ["", ";", " ; "])
def test_validate_empty_players_cell(players):
    clip, reasons = validate_clip_row(HEADERS, ["Pass", "1", "2", "", "", players], PROJECT)
    assert reasons == [] and clip["players"] == []


@pytest.mark.parametrize(("fields", "reason"), [
    (["Pass", "1"], "wrong column count"),
    (["Pass", "1", "2", "", "", "", "extra"], "wrong column count"),
    (["Unknown", "1", "2", "", "", ""], "unknown tag type"),
    (["Pass", "nope", "2", "", "", ""], "start must be a finite number"),
    (["Pass", "nan", "2", "", "", ""], "start must be a finite number"),
    (["Pass", "-1", "2", "", "", ""], "start must be nonnegative"),
    (["Pass", "2", "2", "", "", ""], "end must be greater than start"),
    (["Pass", "5", "1", "", "", ""], "end must be greater than start"),
    (["Pass", "1", "inf", "", "", ""], "end must be a finite number"),
    (["Pass", "1", "2", "", "", "Nobody"], "player Nobody is unknown"),
    (["Pass", "1", "2", "", "", "#"], "player # is unknown"),
])
def test_validate_rejects_bad_rows(fields, reason):
    project_before = copy.deepcopy(PROJECT)
    clip, reasons = validate_clip_row(HEADERS, fields, PROJECT)
    assert clip is None
    assert reason in reasons
    assert PROJECT == project_before


@pytest.mark.parametrize("token", ["Alex", "#7"])
def test_validate_player_name_or_number(token):
    clip, reasons = validate_clip_row(HEADERS, ["Pass", "1", "2", "", "", token], PROJECT)
    assert reasons == [] and clip["players"] == ["p1"]


def test_validate_rejects_ambiguous_player():
    project = {**PROJECT, "players": PROJECT["players"] + [{"id": "p3", "name": "Alex", "number": "7"}]}
    for token in ("Alex", "#7"):
        clip, reasons = validate_clip_row(HEADERS, ["Pass", "1", "2", "", "", token], project)
        assert clip is None and f"player {token} is ambiguous" in reasons


def test_preview_mixed_statuses_and_physical_lines():
    data = ("Tag Type,Start (s),End (s),Label,Players,Clip ID\n\n"
            "Pass,1,2,x,Alex,new\n"
            "Pass,3,2,bad,,new\n"
            "Pass,1,2,x,,other\n").encode()
    result = preview_clip_csv(data, PROJECT)
    assert result["preview_only"] is True
    assert result["summary"] == {"total": 3, "valid": 1, "malformed": 1, "duplicate": 1}
    assert [(row["line"], row["status"]) for row in result["rows"]] == [
        (3, "valid"), (4, "malformed"), (5, "duplicate")]
    assert result["rows"][0] == {
        "line": 3, "status": "valid", "reasons": [],
        "clip": {"tag_type": "Pass", "start": 1.0, "end": 2.0,
                 "label": "x", "notes": "", "players": ["p1"]},
    }
    assert result["rows"][1]["reasons"] == ["end must be greater than start"]
    assert result["rows"][2]["reasons"] == ["same as line 3"]
    assert result["rows"][1]["clip"] is None and result["rows"][2]["clip"] is None


def test_preview_tracks_id_and_normalizable_tuple_on_malformed_rows():
    data = ("Tag Type,Start (s),End (s),Label,Players,Clip ID\n"
            "Pass,1,2,x,Nobody,reserved\n"
            "Pass,4,5,y,,reserved\n"
            "Pass,1,2,x,,\n").encode()
    result = preview_clip_csv(data, PROJECT)
    assert [row["status"] for row in result["rows"]] == ["malformed", "duplicate", "duplicate"]
    assert result["summary"] == {"total": 3, "valid": 0, "malformed": 1, "duplicate": 2}
    assert result["rows"][1]["reasons"] == ["clip id same as line 2"]
    assert result["rows"][2]["reasons"] == ["same as line 2"]


def test_preview_normalizes_label_and_reports_both_collisions():
    data = ("Tag Type,Start (s),End (s),Label,Clip ID\n"
            " Pass ,1,2, x ,same\nPass,1.0,2.0,x,same\n").encode()
    result = preview_clip_csv(data, PROJECT)
    assert result["summary"] == {"total": 2, "valid": 1, "malformed": 0, "duplicate": 1}
    assert result["rows"][1]["reasons"] == [
        "same as line 2", "clip id same as line 2"]


def test_preview_wrong_width_row_still_reserves_present_id():
    data = ("Tag Type,Start (s),End (s),Label,Clip ID\n"
            "Pass,1,2,x,reserved,extra\nPass,3,4,y,reserved\n").encode()
    result = preview_clip_csv(data, PROJECT)
    assert [row["status"] for row in result["rows"]] == ["malformed", "duplicate"]
    assert result["rows"][0]["reasons"] == ["wrong column count"]
    assert result["rows"][1]["reasons"] == ["clip id same as line 2"]


def test_preview_existing_id_empty_ids_and_project_immutability():
    project = {**PROJECT, "clips": [{"id": "taken"}]}
    before = copy.deepcopy(project)
    data = ("Tag Type,Start (s),End (s),Clip ID\n"
            "Pass,0,1,taken\nPass,2,3,\nPass,4,5,   \n").encode()
    result = preview_clip_csv(data, project)
    assert [row["status"] for row in result["rows"]] == ["duplicate", "valid", "valid"]
    assert result["summary"] == {"total": 3, "valid": 2, "malformed": 0, "duplicate": 1}
    assert result["rows"][0]["reasons"] == ["clip id already exists"]
    assert project == before


def test_preview_header_only_and_parser_errors():
    result = preview_clip_csv(b"Tag Type,Start (s),End (s)\n", PROJECT)
    assert result == {"preview_only": True,
                      "summary": {"total": 0, "valid": 0, "malformed": 0, "duplicate": 0},
                      "rows": []}
    with pytest.raises(ValueError, match="missing required header"):
        preview_clip_csv(b"Tag Type,Start (s)\n", PROJECT)
    over = ("Tag Type,Start (s),End (s)\n" +
            "".join(f"Pass,{i},{i + 1}\n" for i in range(5001))).encode()
    with pytest.raises(ValueError, match="^too_many_rows$"):
        preview_clip_csv(over, PROJECT)

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { loadApp } = require("./load_app");

// Contract payloads from the preview response, not from the renderer.
const MIXED = { preview_only: true, summary: { total: 3, valid: 1, malformed: 1, duplicate: 1 }, rows: [
  { line: 2, status: "valid", reasons: [], clip: { tag_type: "Pass", start: 1.5, end: 4.0, label: "x", notes: "", players: ["<player id>"] } },
  { line: 3, status: "malformed", reasons: ["end must be greater than start"], clip: null },
  { line: 4, status: "duplicate", reasons: ["same as line 2"], clip: null },
] };
const EMPTY = { preview_only: true, rows: [], summary: { total: 0, valid: 0, malformed: 0, duplicate: 0 } };
const EVIL = { preview_only: true, summary: { total: 1, valid: 1, malformed: 0, duplicate: 0 }, rows: [
  { line: 2, status: "valid", reasons: ["<script>alert(1)</script>"], clip: {
    tag_type: "Pass", start: 1.5, end: 4, label: "<img src=x onerror=alert(1)>&", notes: "", players: [] } },
] };

test("renders escaped preview rows and replaces them", () => {
  const html = fs.readFileSync(path.resolve(__dirname, "../../templates/index.html"), "utf8");
  assert.match(html, /id="btn-import-preview"[^>]*>Import preview</);
  const { document: doc, calls, evalInApp } = loadApp();
  const region = doc.getElementById("import-preview-results");
  assert.equal(region.closest(".modal-overlay"), null);
  assert.ok(doc.getElementById("tagging-screen").contains(region));
  assert.equal(doc.querySelector('label[for="import-preview-file"]')["for"], "import-preview-file");
  assert.equal(doc.getElementById("import-preview-status").role, "status");
  doc.getElementById("btn-import-preview").focus();
  assert.equal(doc.activeElement.id, "btn-import-preview");
  doc.getElementById("import-preview-file").focus();
  assert.equal(doc.activeElement.id, "import-preview-file");
  evalInApp("currentProject = {id:'keep', clips:[{id:'c1'}]}");
  const before = evalInApp("JSON.stringify(currentProject)"), fetches = calls.fetch.length;
  const show = payload => evalInApp(`renderImportPreview(${JSON.stringify(payload)})`);
  show(MIXED);
  let rows = doc.querySelectorAll("tr[data-status]");
  assert.deepEqual(rows.map(row => row.dataset.status), ["valid", "malformed", "duplicate"]);
  assert.equal(rows[0].children[0].textContent, "2");
  assert.equal(rows[0].children[2].textContent, "Pass 1.5-4 x <player id>");
  assert.match(rows[0].children[2].innerHTML, /&lt;player id&gt;/);
  assert.equal(rows[1].children[2].textContent, "");
  assert.equal(rows[1].children[3].textContent, "end must be greater than start");
  assert.equal(rows[2].children[3].textContent, "same as line 2");
  assert.equal(doc.getElementById("import-preview-summary").textContent, "3 total, 1 valid, 1 malformed, 1 duplicate");
  assert.equal(doc.getElementById("import-preview-status").textContent, "");
  show(EMPTY);
  assert.equal(doc.querySelectorAll("tr[data-status]").length, 0);
  assert.equal(doc.getElementById("import-preview-status").textContent, "No clip rows to preview.");
  assert.equal(doc.getElementById("import-preview-summary").textContent, "0 total, 0 valid, 0 malformed, 0 duplicate");
  show(EVIL);
  const row = doc.querySelector("tr[data-status]");
  assert.equal(doc.querySelectorAll("tr[data-status]").length, 1);
  assert.equal(row.children[2].textContent, "Pass 1.5-4 <img src=x onerror=alert(1)>&");
  assert.match(row.children[2].innerHTML, /&lt;img src=x onerror=alert\(1\)&gt;&amp;/);
  assert.equal(row.querySelector("img"), null);
  assert.match(row.children[3].innerHTML, /&lt;script&gt;/);
  assert.equal(row.querySelector("script"), null);
  assert.equal(calls.fetch.length, fetches);
  assert.equal(evalInApp("JSON.stringify(currentProject)"), before);
});

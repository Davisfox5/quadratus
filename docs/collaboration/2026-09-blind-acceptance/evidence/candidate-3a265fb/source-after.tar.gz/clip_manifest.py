"""In-memory clip-manifest CSV parsing and validation. No external access."""

import csv
import math

_REQUIRED = ("tag type", "start (s)", "end (s)")
_MAX_DATA_ROWS = 5000


def parse_clip_csv(data):
    """Return (headers, records) from UTF-8 bytes with an optional BOM.

    Headers are trimmed and lowercased. Each record is (physical start line,
    fields) with cell text unchanged. Blank records are skipped. Unknown
    columns and wrong-width rows are kept. ValueError on invalid UTF-8,
    missing required headers, or more than 5000 nonblank data rows.
    """
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("CSV is not valid UTF-8") from exc

    lines = text.splitlines(keepends=True)
    consumed = 0

    def _lines():
        nonlocal consumed
        while consumed < len(lines):
            consumed += 1
            yield lines[consumed - 1]

    headers = None
    records = []
    previous_end = 0
    for fields in csv.reader(_lines()):
        start = previous_end + 1
        previous_end = consumed
        if not fields or all(cell == "" for cell in fields):
            continue
        if headers is None:
            headers = [cell.strip().lower() for cell in fields]
            missing = [name for name in _REQUIRED if name not in headers]
            if missing:
                raise ValueError("missing required header: " + ", ".join(missing))
            continue
        if len(records) >= _MAX_DATA_ROWS:
            raise ValueError("too_many_rows")
        records.append((start, fields))
    if headers is None:
        raise ValueError("missing required header: " + ", ".join(_REQUIRED))
    return headers, records


def validate_clip_row(headers, fields, project):
    """Normalize one row from parse_clip_csv, returning (clip, reasons).

    Required, normalized headers are therefore assumed to be present. Player
    names and numbers are matched exactly after trimming each CSV token.
    """
    if len(fields) != len(headers):
        return None, ["wrong column count"]
    row = dict(zip(headers, fields))
    reasons = []

    tag_type = row["tag type"].strip()
    if tag_type not in {tag["name"] for tag in project.get("tag_types", [])}:
        reasons.append("unknown tag type")

    values = {}
    for key, label in (("start (s)", "start"), ("end (s)", "end")):
        try:
            value = float(row[key].strip())
        except ValueError:
            reasons.append(f"{label} must be a finite number")
        else:
            if math.isfinite(value):
                values[label] = value
            else:
                reasons.append(f"{label} must be a finite number")
    if "start" in values and values["start"] < 0:
        reasons.append("start must be nonnegative")
    if "start" in values and "end" in values and values["end"] <= values["start"]:
        reasons.append("end must be greater than start")

    player_ids = []
    for token in filter(None, (part.strip() for part in row.get("players", "").split(";"))):
        if token.startswith("#"):
            number = token[1:]
            matches = ([p for p in project.get("players", [])
                        if number and str(p.get("number", "")) == number])
        else:
            matches = [p for p in project.get("players", []) if p.get("name") == token]
        if len(matches) != 1:
            reasons.append(f"player {token} is {'unknown' if not matches else 'ambiguous'}")
        else:
            player_ids.append(matches[0]["id"])

    if reasons:
        return None, reasons
    return {
        "tag_type": tag_type, "start": values["start"], "end": values["end"],
        "label": row.get("label", ""), "notes": row.get("notes", ""),
        "players": player_ids,
    }, []


def preview_clip_csv(data, project):
    """Assemble a read-only manifest preview entirely in memory."""
    headers, records = parse_clip_csv(data)
    prior_tuples = {}
    prior_ids = {}
    existing_ids = {str(clip.get("id")) for clip in project.get("clips", [])
                    if clip.get("id") is not None}
    rows = []
    counts = {"total": len(records), "valid": 0, "malformed": 0, "duplicate": 0}

    for line, fields in records:
        clip, malformed_reasons = validate_clip_row(headers, fields, project)
        row = dict(zip(headers, fields))
        identity = None
        clip_id = row.get("clip id", "").strip()
        if clip is not None:
            identity = (clip["tag_type"], clip["start"], clip["end"],
                        clip["label"].strip())
        else:
            try:
                start = float(row.get("start (s)", "").strip())
                end = float(row.get("end (s)", "").strip())
                if math.isfinite(start) and math.isfinite(end):
                    identity = (row.get("tag type", "").strip(), start, end,
                                row.get("label", "").strip())
            except ValueError:
                pass

        duplicate_reasons = []
        if identity in prior_tuples:
            duplicate_reasons.append(f"same as line {prior_tuples[identity]}")
        if clip_id:
            if clip_id in prior_ids:
                duplicate_reasons.append(f"clip id same as line {prior_ids[clip_id]}")
            elif clip_id in existing_ids:
                duplicate_reasons.append("clip id already exists")
        if identity is not None:
            prior_tuples.setdefault(identity, line)
        if clip_id:
            prior_ids.setdefault(clip_id, line)

        status = "malformed" if malformed_reasons else "duplicate" if duplicate_reasons else "valid"
        reasons = malformed_reasons if malformed_reasons else duplicate_reasons
        rows.append({"line": line, "status": status, "reasons": reasons,
                     "clip": clip if status == "valid" else None})
        counts[status] += 1
    return {"preview_only": True, "summary": counts, "rows": rows}

"""Focused tests for clip-manifest CSV header decoding and player resolution."""
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import app as application


def _read(raw):
    return application._read_clip_manifest_header(raw)


def _players():
    return [
        {"id": "a1", "name": "Alice", "number": "10"},
        {"id": "b2", "name": "Bob", "number": "7"},
    ]


def _resolve(value, players=None):
    if players is None:
        players = _players()
    return application._resolve_clip_manifest_players(value, players)


def test_bom_crlf_quoted_unknown_and_case():
    raw = b'\xef\xbb\xbf" TAG TYPE ","Start (s)",Extra,"END (S)"\r\n'
    columns, reader = _read(raw)
    assert columns == ["tag type", "start (s)", "extra", "end (s)"]
    assert reader.line_num == 1
    assert list(reader) == []


def test_quoted_multiline_data_remains_readable():
    raw = b'Tag Type,Start (s),End (s),Notes\nPass,1,2,"x\ny"\n'
    columns, reader = _read(raw)
    assert columns[0] == "tag type"
    assert next(reader) == ["Pass", "1", "2", "x\ny"]
    assert reader.line_num == 3


def test_undecodable_bytes_raise():
    with pytest.raises(ValueError, match="undecodable"):
        _read(b"\xff\xfe")


def test_absent_header_raises():
    with pytest.raises(ValueError, match="missing header"):
        _read(b"")
    with pytest.raises(ValueError, match="missing header"):
        _read(b"\n")


def test_missing_required_header_raises():
    with pytest.raises(ValueError, match="missing required header"):
        _read(b"Tag Type,Label,Notes\n")


def test_invalid_header_quoting_raises():
    with pytest.raises(ValueError, match="invalid header quoting"):
        _read(b'"Tag Type,Start (s),End (s)\n')


def test_helper_never_calls_store_or_video(monkeypatch):
    calls = []
    monkeypatch.setattr(application, "_load_projects", lambda *a, **k: calls.append("load"))
    monkeypatch.setattr(application, "_save_projects", lambda *a, **k: calls.append("save"))
    monkeypatch.setattr(application.subprocess, "run", lambda *a, **k: calls.append("video"))
    _read(b"Tag Type,Start (s),End (s)\nPass,1,2\n")
    assert calls == []


def test_resolve_names_numbers_whitespace_and_order():
    assert _resolve("Bob;Alice") == (["b2", "a1"], [])
    assert _resolve("#10;#7") == (["a1", "b2"], [])
    assert _resolve(" Alice ; #7 ") == (["a1", "b2"], [])


def test_resolve_empty_cell():
    assert _resolve("") == ([], [])
    assert _resolve("   ") == ([], [])


def test_resolve_unknown_empty_token_discards_ids():
    assert _resolve("Alice;Nobody") == ([], ["unknown player 'Nobody'"])
    assert _resolve("Alice;") == ([], ["empty player token"])
    assert _resolve("#") == ([], ["empty player token"])


def test_resolve_ambiguous_name_and_number():
    players = _players() + [
        {"id": "a9", "name": "Alice", "number": "99"},
        {"id": "c3", "name": "Cara", "number": "7"},
    ]
    assert _resolve("Alice", players) == ([], ["ambiguous player 'Alice'"])
    assert _resolve("#7", players) == ([], ["ambiguous player '#7'"])


def test_resolve_does_not_mutate_players():
    players = _players()
    snapshot = [dict(p) for p in players]
    _resolve("Alice;#7;Nobody", players)
    assert players == snapshot


def test_resolve_never_calls_store_or_video(monkeypatch):
    calls = []
    monkeypatch.setattr(application, "_load_projects", lambda *a, **k: calls.append("load"))
    monkeypatch.setattr(application, "_save_projects", lambda *a, **k: calls.append("save"))
    monkeypatch.setattr(application.subprocess, "run", lambda *a, **k: calls.append("video"))
    _resolve("Alice")
    assert calls == []

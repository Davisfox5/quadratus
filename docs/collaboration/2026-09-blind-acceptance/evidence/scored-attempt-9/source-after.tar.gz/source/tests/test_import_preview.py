import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import app as application


def _read(data):
    if isinstance(data, str):
        data = data.encode("utf-8")
    return application._clip_manifest_reader(data)


PROJECT = {
    "tag_types": [{"name": "Pass"}, {"name": "Shot"}],
    "players": [
        {"id": "p1", "name": "Alex", "number": "7"},
        {"id": "p2", "name": "Sam", "number": "9"},
    ],
}


def _validate(headers, cells, project=PROJECT):
    return application._validate_clip_manifest_row(headers, cells, project)


def test_header_normalization_retains_optional_and_unknown():
    headers, reader = _read(
        "  TAG TYPE , Start (s),END (s), Label, Clip ID, Foo \nPass,1,2,x,id,y\n"
    )
    assert headers == [
        "tag type", "start (s)", "end (s)", "label", "clip id", "foo"
    ]
    assert reader.line_num == 1
    assert next(reader) == ["Pass", "1", "2", "x", "id", "y"]
    assert reader.line_num == 2


def test_utf8_bom_lf_and_crlf():
    bom = b"\xef\xbb\xbfTag Type,Start (s),End (s)\nPass,1,2\n"
    headers, reader = application._clip_manifest_reader(bom)
    assert headers == ["tag type", "start (s)", "end (s)"]
    assert next(reader) == ["Pass", "1", "2"]

    _, reader = _read("Tag Type,Start (s),End (s)\r\nPass,1,2\r\n")
    assert next(reader) == ["Pass", "1", "2"]
    assert reader.line_num == 2


def test_quoted_multiline_fields_preserve_physical_line_numbers():
    lf = 'Tag Type,Start (s),End (s),Notes\nPass,1,2,"line A\nline B"\nShot,3,4,ok\n'
    _, reader = _read(lf)
    assert next(reader) == ["Pass", "1", "2", "line A\nline B"]
    assert reader.line_num == 3
    assert next(reader)[0] == "Shot" and reader.line_num == 4

    crlf = 'Tag Type,Start (s),End (s),Notes\r\nPass,1,2,"a\r\nb"\r\n'
    _, reader = _read(crlf)
    assert next(reader)[3] == "a\r\nb"
    assert reader.line_num == 3


def test_missing_required_headers():
    with pytest.raises(ValueError, match="missing required header"):
        _read("Label,Notes\nx,y\n")
    with pytest.raises(ValueError, match="Start \\(s\\)"):
        _read("Tag Type,End (s)\nPass,2\n")
    with pytest.raises(ValueError, match="missing required header"):
        _read(b"")


def test_invalid_utf8_and_header_syntax():
    with pytest.raises(ValueError, match="UTF-8"):
        application._clip_manifest_reader(b"Tag Type,Start (s),End (s)\n\xff")
    with pytest.raises(ValueError, match="syntax"):
        _read('"Tag Type,Start (s),End (s)\nPass,1,2\n')


def test_valid_row_normalizes_fields_and_ignores_extra_columns():
    headers = ["tag type", "start (s)", "end (s)", "label", "notes",
               "players", "duration (s)", "unknown"]
    clip, reasons = _validate(
        headers, [" Pass ", "1.5", "4", " x ", "note", " Alex ; #9 ", "2.5", "x"]
    )
    assert reasons == []
    assert clip == {"tag_type": "Pass", "start": 1.5, "end": 4.0,
                    "label": " x ", "notes": "note", "players": ["p1", "p2"]}


def test_optional_fields_default_and_wrong_column_count():
    headers = ["tag type", "start (s)", "end (s)"]
    clip, reasons = _validate(headers, ["Shot", "0", "1"])
    assert clip["label"] == clip["notes"] == ""
    assert clip["players"] == [] and reasons == []
    assert _validate(headers, ["Shot", "0"])[0] is None
    assert _validate(headers, ["Shot", "0"])[1] == ["wrong column count"]


@pytest.mark.parametrize("cells, reason", [
    (["pass", "0", "1"], "unknown tag type"),
    (["Pass", "nan", "1"], "start must be a finite number"),
    (["Pass", "0", "inf"], "end must be a finite number"),
    (["Pass", "-1", "1"], "start must be non-negative"),
    (["Pass", "2", "2"], "end must be greater than start"),
])
def test_tag_and_time_validation(cells, reason):
    clip, reasons = _validate(["tag type", "start (s)", "end (s)"], cells)
    assert clip is None and reason in reasons


def test_players_require_one_exact_name_or_number_match():
    headers = ["tag type", "start (s)", "end (s)", "players"]
    ambiguous = {**PROJECT, "players": PROJECT["players"] + [
        {"id": "p3", "name": "Other", "number": "7"}
    ]}
    assert "exactly one" in _validate(headers, ["Pass", "0", "1", "#7"], ambiguous)[1][0]
    assert "exactly one" in _validate(headers, ["Pass", "0", "1", "alex"])[1][0]
    assert "exactly one" in _validate(headers, ["Pass", "0", "1", "Nobody"])[1][0]
    assert "empty" in _validate(headers, ["Pass", "0", "1", "Alex;"])[1][0]
